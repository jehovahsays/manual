// Do not delete the last line of this file because the logger will break and delete entire file. 
var texts = [

"home",
"about",
"site_map",
"privacy",
"terms",
"cookies",
];var tc = TagCloud('.content', texts);console.log(tc);