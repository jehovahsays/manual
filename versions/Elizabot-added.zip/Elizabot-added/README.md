# manual
<br>
<br>
drop this folder into an http server<br>
that has php open browser navigate to http://127.0.0.1/manual/index.html<br>
first add your intelligence using the first input box<br>
then after you complete that ask the chat bot some questions<br>
using the input box at the bottom of the page.<br>
if the chat bot seems smart or intelligent let me know thanks.<br>
Please remember to get a full experience of this repository website<br>
if you are a develepoer make this unfinish repository into something better in your own named repository<br>
visit http://morgansbyers.scienceontheweb.net/index.html
<br>
<br>
speech utterance from back end and front end added
unfinished still working on the loggers<br>
these loggers write real-time user input data to pages<br>
the loggers usually break because of human developer errors<br>
bot is 3d visualization of search engine database<br>
the opacity animation is random base on input value<br>
the 3d data visualization is random animation<br>
the chat bot responses are random<br>
if a visitor searched for the keyword math<br>
php creates a default template page for the keyword math<br>
all keywords are stored in chat bot language file<br>
all keywords are stored in the 3d data visualization in real-time<br>
all keywords are stored on the homepage on html unordered list<br>
html unordered list is connected to search engine box<br>
using javascript and css.
fix what you find was incorrect.<br>
if you know how to fix it just fix it.<br>
if file exsist php api shows link to file.<br>
if file does not exist php api rest creates the file and link.<br>
i removed text to speech from the website.<br>
i added a delete button at bottom of every page a user creates.<br>
<br>
welcome to:<br>
<H3>manual</H3><br>
For educational purposes only.<br>
<a href="http://jehovahsays.github.io/manual/how/map.html">click here</a> to view how the search engine works<br>
hardware: iphone<br>
software: phpwin iphone app<br>
http web server with php<br>
know how to write html,js,css,and php.<br>
no internet connection needed<br>
After you download<br>
edit anything and everything<br>
this should work offline<br>
no external functions<br> 
no external hyperlinks<br>
no cookies,no gps,no mic,no camera,<br>
no puchase buttons.<br>
my name is morgan shatee' byers,<br>
my number is 770-687-8847<br>
<br>
<br>
<a href="https://youtube.com/@jehovahsaysnetworth?si=FRrFrG_K02C38K_G">
youtube channel</a>
<br>