var texts = [
"playlist",
"tv",
"edit",
"chatbot",
"tagcloud",
"articles",
"dictionary",
"reviews",
"elizabot",
"database",
];var tc = TagCloud('.content', texts);console.log(tc);