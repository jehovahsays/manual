# manual
<br>
to get full experience of website visit<br>
http://morgansbyers.scienceontheweb.net/index.html<br>
# recent updates<br>
i upgraded database to spell out input data<br>
this allows for previewing the real-time speech utterances of chatbot responses<br>
i have connected a logger that writes the user data input<br>
into the elizabot data file of elizaInitials responses<br>
this will allow elizabot to choose user data to talk<br>
i added the #urls back for short urls<br>
merged multiple projects i was working on in this update.<br>
I added SpeechSynthesisUtterance to ELIZA chat bot.<br>
ELIZA is an early natural language processing computer program<br>
developed from 1964 to 1967 at MIT by Joseph Weizenbaum.<br>
<br>
<a href="https://youtube.com/@jehovahsaysnetworth">
youtube channel</a>
<br>