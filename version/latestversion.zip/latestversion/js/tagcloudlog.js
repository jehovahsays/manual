var texts = [
"index",
"database",
"about",
];var tc = TagCloud('.content', texts);console.log(tc);